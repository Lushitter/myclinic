srbac
=====

Version of SRBAC (http://www.yiiframework.com/extension/srbac/) with support of groups
