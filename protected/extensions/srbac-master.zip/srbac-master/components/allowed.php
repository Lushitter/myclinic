<?php 
 return array(
	'AwIndex',
	'SiteIndex',
	'SiteError',
	'SiteLogin',
	'SiteLogout'
);
?>